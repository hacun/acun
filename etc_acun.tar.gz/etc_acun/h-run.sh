#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Config dosyanızın adı Flight Sheet’te “Custom config filename” olarak verilecek (ör: config.json)
CONF_FILE="${CUSTOM_CONFIG_FILENAME:-config.json}"

if [[ ! -f "$CONF_FILE" ]]; then
  echo "[ERR] Config file not found: $CONF_FILE"
  exit 1
fi

# Ortam
export PYTHONUNBUFFERED=1

# Python/ikili nasıl ise ona göre çağır:
if [[ -x "./run.sh" ]]; then
  exec ./run.sh
else
  echo "[ERR] run.sh not present"
  exit 1
fi
