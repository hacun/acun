cat << 'EOF' | tee /hive/miners/custom/etc_acun/h-run.sh >/dev/null
#!/usr/bin/env bash
cd /hive/miners/custom/etc_acun
/usr/bin/python3 -u main.py --config config.json
EOF

chmod +x /hive/miners/custom/etc_acun/h-run.sh
