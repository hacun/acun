#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
echo "[DBG] SCRIPT_DIR=${SCRIPT_DIR}"
echo "[DBG] PWD(before)=$(pwd)"
cd "$SCRIPT_DIR"
echo "[DBG] PWD(after)=$(pwd)"
echo "[DBG] ls -la:"
ls -la

CONF_FILE="${CUSTOM_CONFIG_FILENAME:-config.json}"
export PYTHONUNBUFFERED=1

if [[ -f "./run.sh" ]]; then
  echo "[DBG] launching: bash ./run.sh"
  exec bash ./run.sh   # '-x' zorunluluğunu kaldırdık
else
  echo "[ERR] run.sh missing in $SCRIPT_DIR"
  exit 1
fi
