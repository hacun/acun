#!/usr/bin/env bash
# Minimal/no-op. İleride HiveOS formatında metrik basmak istersen ekleriz.
true