# main.py — server-only miner launcher (no RPC)
import os, json, time, signal, sys, argparse
from pathlib import Path
import struct
import numpy as np
import httpx  # for server /work and /submit
import threading

# Optional pyopencl
try:
    import pyopencl as cl
except Exception:
    cl = None

TIME_SLEEP_FOR_DAG=15
BIND_DELAY=1
GLOBAL_SIZE_CHUNK=4096

API_HEADERS = {}  # run-time'da doldurulacak

STOP_EVENT = threading.Event()

def sigterm_handler(signum, frame):
    log("SIGTERM alındı, düzgün çıkış...")
    STOP_EVENT.set()
    # Thread’ler kendi döngülerinde STOP_EVENT’i görüyor ve çıkıyor.

def _align_up(x, a):
    return ((int(x) + int(a) - 1) // int(a)) * int(a)

def pick_local_size(dev, krn, user_local: int | None) -> int:
    """
    workgroup_size (local size) seçimi:
    - Kullanıcı verdiyse → pref multiple'a hizala ve MAX_WORK_GROUP_SIZE'ı aşma.
    - Vermediyse → preferred multiple * (mümkün olan en büyük katsayı) ama 256-512 bandında kal.
    """
    max_wg = dev.get_info(cl.device_info.MAX_WORK_GROUP_SIZE)  # cihaz sınırı (örn. 1024)
    try:
        pref = krn.get_work_group_info(cl.kernel_work_group_info.PREFERRED_WORK_GROUP_SIZE_MULTIPLE, dev)
    except Exception:
        pref = 32  # NVIDIA için tipik; AMD'de 64 olur. Erişilemezse konservatif ol.

    if user_local and user_local > 0:
        l = min(int(user_local), int(max_wg))
        l = max(pref, (l // pref) * pref)  # pref katına indir
        return int(l) if l > 0 else int(pref)

    # Auto: 256’yı hedefle; mümkün değilse pref’in uygun katına indir
    target = 256
    l = min(target, int(max_wg))
    l = max(pref, (l // pref) * pref)
    return int(l) if l > 0 else int(pref)

def pick_global_size(dev, lsize, user_global):
    mcu = dev.get_info(cl.device_info.MAX_COMPUTE_UNITS)
    if user_global and user_global > 0:
        return _align_up(user_global, lsize)

    # Daha muhafazakâr bant
    g = max(mcu * 2048, 1) * lsize
    g_min = max(mcu * 512, 1) * lsize
    g_max = max(mcu * GLOBAL_SIZE_CHUNK, 1) * lsize   # <- 8192 yerine 4096
    g = min(max(g, g_min), g_max)
    return int(g)

def find_dag_by_epoch_token(dag_dir_path: str, epoch: int) -> str | None:
    """
    Klasörde adı '-' ile bölündüğünde epoch'u (örn. '387') bir TOKEN olarak içeren
    tam olarak 1 dosya olmalı.
    Örn: full-R23-387-17b0a10decbd0180  -> tokenlar: ['full', 'R23', '387', '17b0a10decbd0180']
    """
    d = Path(dag_dir_path)
    if not d.exists() or not d.is_dir():
        log(f"[DAG-SCAN] dir not found or not dir: {dag_dir_path}")
        return None

    want = str(int(epoch))
    hits = []
    for p in d.iterdir():
        if not p.is_file():
            continue
        tokens = p.name.split("-")
        if want in tokens:
            hits.append(str(p))

    if len(hits) == 0:
        log(f"[DAG-SCAN] no file with epoch token '{want}' in '{dag_dir_path}'")
        return None
    if len(hits) > 1:
        names = ", ".join(Path(h).name for h in hits)
        log(f"[DAG-SCAN] ambiguous epoch '{want}' in '{dag_dir_path}': {names}")
        return None

    log(f"[DAG-SCAN] epoch '{want}' -> {Path(hits[0]).name}")
    return hits[0]

def bind_dag_for_epoch(ctxd, dev, src, build_opts, dag_dir_path: str, epoch_val: int):
    cand = find_dag_by_epoch_token(dag_dir_path, epoch_val)
    if not cand:
        raise FileNotFoundError(f"No unique DAG for epoch '{epoch_val}' in '{dag_dir_path}'")

    dag_u32, hdr_off = map_dag_u32_noheader(Path(cand))
    dag_flat_u32 = dag_u32.astype(np.uint32, copy=False).reshape(-1)
    dag_words = np.uint32(dag_flat_u32.size)

    if ctxd is not None:
        try: ctxd.close()
        except Exception: pass
        ctxd = None

    new_ctx = OclDeviceCtx(dev, dag_flat_u32, src, build_opts)
    log(f"[DAG] bind -> '{Path(cand).name}' words={int(dag_words):,} (~{int(dag_words)*4/1024/1024:.1f} MiB)")
    log(f"[OCL] DAG uploaded on '{dev.name}' in {new_ctx.dag_copy_ms:.1f} ms")
    return new_ctx, cand, dag_words

def is_file(path: str) -> bool:
    try:
        return Path(path).is_file()
    except Exception:
        return False

# =============== tiny logger ===============
_t0 = time.time()
def log(msg: str):
    dt = time.time() - _t0
    print(f"[{dt:7.3f}s] {msg}", flush=True)

# =============== basic IO helpers ===============
BASE_DIR = Path(__file__).resolve().parent

def load_cfg(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def resolve_path(p: str | None) -> str | None:
    if not p: return p
    pp = Path(p)
    return str(pp if pp.is_absolute() else (BASE_DIR / pp).resolve())

def ensure_dirs(*paths):
    for d in paths:
        if d:
            Path(d).mkdir(parents=True, exist_ok=True)

def deep_merge(base: dict, override: dict) -> dict:
    out = dict(base or {})
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def minimal_validate(cfg: dict):
    # Server-only: server.url ve mining.kernel_path zorunlu
    must = [
        ("server.url", cfg.get("server", {}).get("url")),
        ("mining.kernel_path", cfg.get("mining", {}).get("kernel_path")),
    ]
    missing = [k for k, v in must if not v]
    if missing:
        raise ValueError("Missing required config fields: " + ", ".join(missing))

# =============== HiveOS ENV overrides ===============
def env_overrides() -> dict:
    ov = {"server": {}, "mining": {}, "identity": {}, "logging": {}}

    # Server URL (custom)
    if os.getenv("HIVE_SERVER_URL"):
        ov["server"]["url"] = os.getenv("HIVE_SERVER_URL")

    # Identity
    if os.getenv("HIVE_WORKER"):
        ov["identity"]["worker"] = os.getenv("HIVE_WORKER")
    if os.getenv("HIVE_WALLET"):
        ov["identity"]["wallet"] = os.getenv("HIVE_WALLET")

    # Mining
    if os.getenv("HIVE_OCL_OPTS"):
        ov["mining"]["ocl_build_opts"] = os.getenv("HIVE_OCL_OPTS")
    if os.getenv("HIVE_DAG_PATH"):
        ov["mining"]["dag_dir"] = os.getenv("HIVE_DAG_PATH")
    if os.getenv("HIVE_KERNEL_PATH"):
        ov["mining"]["kernel_path"] = os.getenv("HIVE_KERNEL_PATH")

    # Logging
    if os.getenv("HIVE_LOG_DIR"):
        ov["logging"]["log_dir"] = os.getenv("HIVE_LOG_DIR")
    if os.getenv("HIVE_STATS_DIR"):
        ov["logging"]["stats_dir"] = os.getenv("HIVE_STATS_DIR")

    # Temizle
    def strip_empty(d):
        if isinstance(d, dict):
            return {k: strip_empty(v) for k, v in d.items() if v not in [None, {}, []]}
        return d
    return strip_empty(ov)

# =============== HiveOS miner_stat.json ===============
START_TS = time.time()

def write_miner_stat(stats_dir, hashrate_hs, shares_ok, shares_rej, temp_per_gpu, power_w):
    out = {
        "ver": "1.0",
        "nvml": False,
        "hs": [int(hashrate_hs or 0)],
        "temp": temp_per_gpu or [],
        "fans": [],
        "power": int(power_w or 0),
        "algo": "etchash",
        "coin": "ETC",
        "uptime": int(time.time() - START_TS),
        "ar": [int(shares_ok or 0), int(shares_rej or 0), 0],
        "solv": 0,
        "vernum": 1
    }
    ensure_dirs(stats_dir)
    with open(os.path.join(stats_dir, "miner_stat.json"), "w") as f:
        json.dump(out, f)

# =============== Hex / DAG helpers ===============
def map_dag_u32_noheader(path: Path):
    arr = np.memmap(str(path), dtype=np.dtype('<u4'), mode='r', offset=8)
    if arr.size == 0:
        raise RuntimeError("DAG memmap empty (check file path/permissions)")
    return arr, 8

def hex_to_bytes_no0x(s: str, pad_to: int | None = None) -> bytes:
    if s is None:
        raise ValueError("hex_to_bytes_no0x: input is None")
    raw = str(s).strip().lower()
    if raw.startswith("0x"):
        raw = raw[2:]
    raw = "".join(ch for ch in raw if ch in "0123456789abcdef")
    if len(raw) == 0:
        raise ValueError("hex_to_bytes_no0x: empty after sanitization")
    if len(raw) % 2 == 1:
        raw = "0" + raw
    b = bytes.fromhex(raw)
    if pad_to is not None and len(b) < pad_to:
        b = b"\x00" * (pad_to - len(b)) + b
    return b

def u64_to_hex0x_be(n: int) -> str:
    return "0x" + struct.pack(">Q", n & 0xFFFFFFFFFFFFFFFF).hex()

# =============== Server HTTP helpers ===============
def srv_get_work(server_url: str, want_ms: int, hashrate_hs: int | None):
    payload = {"want_ms": int(want_ms)}
    if hashrate_hs and hashrate_hs > 0:
        payload["hashrate_hs"] = int(hashrate_hs)

    with httpx.Client(timeout=5.0, headers=API_HEADERS) as c:
        r = c.post(server_url.rstrip("/") + "/work", json=payload)
        r.raise_for_status()
        return r.json()

def srv_submit_share(server_url: str, nonce_hex: str, powhash_hex: str, mixdigest_hex: str, extra=None):
    payload = {
        "nonce_hex": nonce_hex,
        "powhash_hex": powhash_hex,
        "mixdigest_hex": mixdigest_hex,
        "extra": extra or {}
    }
    with httpx.Client(timeout=8.0, headers=API_HEADERS) as c:
        r = c.post(server_url.rstrip("/") + "/submit", json=payload)
        r.raise_for_status()
        return r.json()

# =============== GpuWorker Thread ===============
class GpuWorker(threading.Thread):
    def __init__(self, dev, idx, *,
                 dag_dir_path: str,
                 server_url: str,
                 kernel_src: str,
                 build_opts: str,
                 want_ms: int,
                 user_local: int | None,
                 user_global: int | None,
                 stats_slot: dict):
        super().__init__(daemon=True, name=f"gpu-{idx}")
        self.dev = dev
        self.idx = idx
        self.dag_dir_path = dag_dir_path
        self.server_url = server_url
        self.kernel_src = kernel_src
        self.build_opts = build_opts
        self.want_ms = want_ms
        self.user_local = user_local
        self.user_global = user_global
        self.stats_slot = stats_slot  # { 'hs':0, 'accepted':0, 'rejected':0, 'dag': '', 'epoch': None }

        self.ctxd = None
        self.active_epoch = None
        self.dag_words = None
        self.dag_file_path = None

        # seçilen boyutlar
        self.lsize = None
        self.gsize = None

    def bind_dag_if_needed(self, epoch_val: int):
        if (self.ctxd is None) or (self.active_epoch != epoch_val):
            log(f"[BOOT] [GPU{self.idx}] started; delaying {TIME_SLEEP_FOR_DAG}s before next…")

            time.sleep(BIND_DELAY) # 1 sn
            self.ctxd, self.dag_file_path, self.dag_words = bind_dag_for_epoch(
                ctxd=self.ctxd, dev=self.dev, src=self.kernel_src, build_opts=self.build_opts,
                dag_dir_path=self.dag_dir_path, epoch_val=epoch_val
            )
            self.active_epoch = epoch_val
            # boyut seçimi
            self.lsize = pick_local_size(self.dev, self.ctxd.krn, self.user_local)
            self.gsize = pick_global_size(self.dev, self.lsize, self.user_global)
            log(f"[GPU{self.idx}] [SIZES] local={self.lsize} global={self.gsize} user_global={'yes' if self.user_global else 'auto'}")

    def autotune_global(self, k_ms: float):
        if (self.user_global is not None) or (k_ms <= 0):
            return
        target = float(self.want_ms)
        scale = target / k_ms
        if 0.85 <= scale <= 1.15:
            return
        new_g = int(self.gsize * max(0.7, min(1.5, scale)))
        new_g = _align_up(new_g, self.lsize)

        mcu  = self.dev.get_info(cl.device_info.MAX_COMPUTE_UNITS)
        gmin = max(mcu * 512, 1) * self.lsize
        gmax = max(mcu * GLOBAL_SIZE_CHUNK, 1) * self.lsize
        new_g = min(max(new_g, gmin), gmax)
        if new_g != self.gsize:
            log(f"[GPU{self.idx}] [TUNE] global {self.gsize} -> {new_g} (k_ms={k_ms:.1f}, want={target:.1f})")
            self.gsize = new_g

    def _rebuild_ctx(self, reason: str):
        log(f"[GPU{self.idx}] [RECOVER] rebuilding context due to: {reason}")
        try:
            if self.ctxd:
                self.ctxd.close()
        except Exception:
            pass
        self.ctxd = None
        # epoch’u unutturalım ki bind_dag_if_needed() zorunlu rebind yapsın
        self.active_epoch = None
        time.sleep(1.0)

    def run(self):
        log(f"[GPU{self.idx}] start on device '{self.dev.name.strip()}'")
        last_stat_ts = 0.0

        while not STOP_EVENT.is_set():
            try:
                resp = srv_get_work(self.server_url, want_ms=self.want_ms,
                                    hashrate_hs=int(self.stats_slot.get('hs', 0)) or None)
                if not resp.get("ok"):
                    time.sleep(1.0); continue

                w = resp["work"]; rg = resp["range"]
                epoch_val = int(w.get("epoch")) if w.get("epoch") is not None else None
                if epoch_val is None:
                    log(f"[GPU{self.idx}] [ERR] server work has no valid epoch")
                    time.sleep(2.0); continue

                # Context/DAG
                self.bind_dag_if_needed(epoch_val)

                powhash_hex = str(w["pow_hash"]).lower()
                target_hex  = str(w["target"]).lower()
                powhash = hex_to_bytes_no0x(powhash_hex, pad_to=32)
                target  = hex_to_bytes_no0x(target_hex,  pad_to=32)

                try:
                    self.ctxd.reset_outputs()
                    self.ctxd.upload_small_inputs(powhash, target)
                except Exception as e:
                    msg = str(e)
                    if "INVALID_COMMAND_QUEUE" in msg or "CL_INVALID_COMMAND_QUEUE" in msg:
                        self._rebuild_ctx("invalid command queue on small input upload")
                        continue
                    raise

                start_i = int(rg["nonce_start"]) & ((1<<64)-1)
                end_i   = int(rg["nonce_end"])   & ((1<<64)-1)
                count   = int(rg["count"])
                if count <= 0:
                    time.sleep(0.5); continue

                t0 = time.time()
                
                try:
                    evt = self.ctxd.enqueue_kernel(
                        dag_words=self.dag_words,
                        pow_buf=self.ctxd.pow_buf,
                        target_buf=self.ctxd.target_buf,
                        start_nonce=np.uint64(start_i),
                        nonce_end=np.uint64(end_i),
                        global_work=self.gsize,
                        local_work=self.lsize,
                    )
                    evt.wait()
                except Exception as e:
                    msg = str(e)
                    # Profiling bilgisi yoksa: rebuild yapma, raise etme
                    if ("PROFILING_INFO_NOT_AVAILABLE" in msg or "CL_PROFILING_INFO_NOT_AVAILABLE" in msg):
                        # Artık profil kullanmadığımız için sadece yutuyoruz
                        pass
                    elif ("INVALID_COMMAND_QUEUE" in msg or "CL_INVALID_COMMAND_QUEUE" in msg or
                        "CL_OUT_OF_RESOURCES" in msg or "DEVICE_NOT_AVAILABLE" in msg):
                        self._rebuild_ctx(f"kernel enqueue/wait failed: {msg}")
                        continue
                    else:
                        raise

                t_elapsed = time.time() - t0
                k_ms =  t_elapsed * 1000.0

                if t_elapsed > 0:
                    self.stats_slot['hs'] = int(count / t_elapsed)

                self.stats_slot['epoch'] = self.active_epoch
                self.stats_slot['dag'] = Path(self.dag_file_path).name

                self.autotune_global(k_ms)

                log(f"[GPU{self.idx} R{self.active_epoch}] powHash={powhash_hex[:18]}... "
                    f"count={count} time={k_ms:.1f} ms ~{self.stats_slot['hs']/1e6:.2f} MH/s dag='{self.stats_slot['dag']}'")

                if self.ctxd.read_flag() != 0:
                    nonce_val = self.ctxd.read_nonce()
                    mix_bytes = self.ctxd.read_mix()
                    nonce_hex = u64_to_hex0x_be(nonce_val)
                    mix_hex   = "0x" + mix_bytes.hex()
                    pow_hex   = "0x" + powhash.hex()
                    sres = srv_submit_share(self.server_url, nonce_hex, pow_hex, mix_hex,
                                            extra={"gpu": self.idx, "k_ms": k_ms, "count": count, "hashrate_hs": self.stats_slot['hs'],
                                                   "epoch": self.active_epoch, "dag_file": self.stats_slot['dag']})
                    log(f"[GPU{self.idx}] [SUBMIT] {sres}")

                now = time.time()
                if now - last_stat_ts > 10:
                    last_stat_ts = now

            except Exception as e:
                # Genel yakalama: queue/context hatalarında self-heal dene
                msg = str(e)
                if ("INVALID_COMMAND_QUEUE" in msg or "CL_INVALID_COMMAND_QUEUE" in msg or
                    "CL_OUT_OF_RESOURCES" in msg or "DEVICE_NOT_AVAILABLE" in msg):
                    self._rebuild_ctx(f"outer loop: {msg}")
                    continue
                log(f"[GPU{self.idx}] [ERR] {e}")
                time.sleep(1.0)

        # temiz kapanış
        try:
            if self.ctxd: self.ctxd.close()
        except Exception:
            pass
        log(f"[GPU{self.idx}] stopped")


# =============== OpenCL wrapper ===============
class OclDeviceCtx:
    def __init__(self, dev, dag_flat_u32: np.ndarray, build_src: str, build_opts: str):
        self.dev  = dev
        self.name = dev.name.strip()

        self.ctx   = cl.Context([dev])
        #self.queue = cl.CommandQueue(self.ctx, properties=cl.command_queue_properties.PROFILING_ENABLE)
        self.queue = cl.CommandQueue(self.ctx) # <-- PROFILING_ENABLE yok, sürekli hatadan dolayı kaldırdık
        self.profiling_ok = False   # <-- bayrak: hep duvar saati

        self.mf    = cl.mem_flags

        self.prg = cl.Program(self.ctx, build_src).build(options=build_opts or "")
        self.krn = self.prg.search_nonce

        t0 = time.time()
        self.dag_buf = cl.Buffer(self.ctx, self.mf.READ_ONLY | self.mf.COPY_HOST_PTR, hostbuf=dag_flat_u32)
        self.dag_copy_ms = (time.time() - t0) * 1000.0

        self.pow_buf    = None
        self.target_buf = None

        self.h_flag  = np.zeros(1, dtype=np.uint32)
        self.h_nonce = np.zeros(1, dtype=np.uint64)
        self.h_cmix  = np.zeros(32, dtype=np.uint8)

        self.d_flag  = cl.Buffer(self.ctx, self.mf.READ_WRITE | self.mf.COPY_HOST_PTR, hostbuf=self.h_flag)
        self.d_nonce = cl.Buffer(self.ctx, self.mf.READ_WRITE | self.mf.COPY_HOST_PTR, hostbuf=self.h_nonce)
        self.d_cmix  = cl.Buffer(self.ctx, self.mf.READ_WRITE | self.mf.COPY_HOST_PTR, hostbuf=self.h_cmix)

    def close(self):
        try:
            # Device buffers
            for buf in [self.pow_buf, self.target_buf, self.d_flag, self.d_nonce, self.d_cmix, self.dag_buf]:
                try:
                    if buf is not None:
                        buf.release()
                except Exception:
                    pass
        finally:
            # Queue ve Context
            try:
                if getattr(self, "queue", None) is not None:
                    try:
                        self.queue.finish()
                    except Exception:
                        pass
                    try:
                        self.queue.release()
                    except Exception:
                        pass
            except Exception:
                pass
            try:
                if getattr(self, "ctx", None) is not None:
                    try:
                        self.ctx.release()
                    except Exception:
                        pass
            except Exception:
                pass

            # Alanları None’la (geçersiz erişimi erken yakalayalım)
            self.pow_buf = None
            self.target_buf = None
            self.d_flag = None
            self.d_nonce = None
            self.d_cmix = None
            self.dag_buf = None
            self.queue = None
            self.ctx = None

    def reset_outputs(self):
        cl.enqueue_fill_buffer(self.queue, self.d_flag,  np.uint32(0), 0, self.h_flag.nbytes)
        cl.enqueue_fill_buffer(self.queue, self.d_nonce, np.uint32(0), 0, self.h_nonce.nbytes)
        cl.enqueue_fill_buffer(self.queue, self.d_cmix,  np.uint32(0), 0, self.h_cmix.nbytes)
        self.queue.finish()

    def upload_small_inputs(self, powhash: bytes, target: bytes):
        if self.pow_buf is not None: self.pow_buf.release(); self.pow_buf = None
        if self.target_buf is not None: self.target_buf.release(); self.target_buf = None

        pow_np = np.frombuffer(powhash, dtype=np.uint8)
        tgt_np = np.frombuffer(target,  dtype=np.uint8)
        if pow_np.size != 32 or tgt_np.size != 32:
            raise ValueError("powhash/target must be 32 bytes")

        self.pow_buf    = cl.Buffer(self.ctx, self.mf.READ_ONLY  | self.mf.COPY_HOST_PTR, hostbuf=pow_np)
        self.target_buf = cl.Buffer(self.ctx, self.mf.READ_ONLY  | self.mf.COPY_HOST_PTR, hostbuf=tgt_np)

    def enqueue_kernel(self, *, dag_words: np.uint32, pow_buf, target_buf,
                       start_nonce: np.uint64, nonce_end: np.uint64,
                       global_work: int, local_work: int):
        i = 0
        self.krn.set_arg(i, self.dag_buf);                i += 1
        self.krn.set_arg(i, np.uint32(dag_words));        i += 1
        self.krn.set_arg(i, pow_buf);                     i += 1
        self.krn.set_arg(i, target_buf);                  i += 1
        self.krn.set_arg(i, np.uint64(start_nonce));      i += 1
        self.krn.set_arg(i, np.uint64(nonce_end));        i += 1
        self.krn.set_arg(i, self.d_nonce);                i += 1
        self.krn.set_arg(i, self.d_cmix);                 i += 1
        self.krn.set_arg(i, self.d_flag);                 i += 1

        gsize = (int(global_work),)
        lsize = (int(local_work),)
        evt = cl.enqueue_nd_range_kernel(self.queue, self.krn, gsize, lsize)
        return evt

    def read_flag(self) -> int:
        cl.enqueue_copy(self.queue, self.h_flag, self.d_flag); self.queue.finish()
        return int(self.h_flag[0])

    def read_nonce(self) -> int:
        cl.enqueue_copy(self.queue, self.h_nonce, self.d_nonce); self.queue.finish()
        return int(self.h_nonce[0])

    def read_mix(self) -> bytes:
        cl.enqueue_copy(self.queue, self.h_cmix, self.d_cmix); self.queue.finish()
        return bytes(self.h_cmix.tolist())

# =============== Server-mode runner ===============
def run_opencl_with_server(
    dag_dir_path: str,
    server_url: str,
    cl_file: Path,
    build_opts: str,
    stats_dir: str,
    global_work: int = 0,
    workgroup_size: int = 0,
    want_ms: int = 800,
    debug: bool = False,
):
    if cl is None:
        raise RuntimeError("pyopencl is required")

    # --- Platform & device discovery (robust) ---
    plats = cl.get_platforms()
    if not plats:
        raise RuntimeError("No OpenCL platforms found")

    devices = []
    # Detaylı env log
    log("[OCL] platforms found: " + ", ".join([f"'{p.name.strip()}'" for p in plats]))

    for p in plats:
        gpus = []
        alive = []
        try:
            gpus = p.get_devices(device_type=cl.device_type.GPU)
        except Exception as e:
            log(f"[OCL] cannot enumerate devices on platform '{p.name.strip()}': {e}")

        if gpus:
            for d in gpus:
                try:
                    if not d.get_info(cl.device_info.AVAILABLE):
                        continue
                    if d.get_info(cl.device_info.GLOBAL_MEM_SIZE) <= 0:
                        continue
                    alive.append(d)
                except Exception:
                    continue

            if not alive:
                log(f"[OCL] platform '{p.name.strip()}' has no *active* GPU devices (skipping)")
                continue
        else:
            log(f"[OCL] platform '{p.name.strip()}' has no GPU devices (skipping)")


        # Bu platformun aktif GPU'larını ekle
        for d in alive:
            devices.append((p, d))

    if devices:
        log("[OCL] selected devices: " + ", ".join([f"{p.name.strip()}::{d.name.strip()}" for (p, d) in devices]))
    else:
        # Tanı için tüm platform & device dökümü
        dump = []
        for p in plats:
            try:
                p_devs = p.get_devices(device_type=cl.device_type.ALL)
            except Exception as e:
                dump.append(f"  - {p.name.strip()}: <enum error: {e}>")
                continue
            dump.append(f"  - {p.name.strip()}: " + ", ".join([d.name.strip() for d in p_devs]) if p_devs else f"  - {p.name.strip()}: <no devices>")
        raise RuntimeError("No usable OpenCL GPU devices found\n" + "\n".join(dump))

    # Aşağıda eskiden 'devs' kullandığınız yerde bunu kullanacağız:
    devs = [d for (_, d) in devices]

    # kernel kaynak
    src = cl_file.read_text(encoding="utf-8")

    # kullanıcı override: 0/None → auto
    user_local  = workgroup_size if workgroup_size and workgroup_size > 0 else None
    user_global = global_work    if global_work    and global_work    > 0 else None

    # Per-GPU paylaşılan stat slotları
    per_gpu = []
    workers = []
    for i, dev in enumerate(devs):
        slot = {'hs': 0, 'accepted': 0, 'rejected': 0, 'dag': '', 'epoch': None}
        per_gpu.append(slot)
        w = GpuWorker(dev, i,
                      dag_dir_path=dag_dir_path,
                      server_url=server_url,
                      kernel_src=src,
                      build_opts=build_opts,
                      want_ms=want_ms,
                      user_local=user_local,
                      user_global=user_global,
                      stats_slot=slot)
        w.start()
        workers.append(w)

        log(f"[BOOT] worker-{i} started; delaying {TIME_SLEEP_FOR_DAG}s before next…")
        time.sleep(TIME_SLEEP_FOR_DAG)        


    last_stat_ts = 0.0
    try:
        while not STOP_EVENT.is_set():
            time.sleep(0.5)
            now = time.time()
            if now - last_stat_ts > 10:
                # rig toplam stat
                total_hs = sum(int(s['hs'] or 0) for s in per_gpu)
                # gpu temp/power ölçmüyorsak placeholder
                temps = [60 for _ in per_gpu]
                power = 110 * max(1, len(per_gpu))
                write_miner_stat(stats_dir, hashrate_hs=total_hs,
                                 shares_ok=sum(s['accepted'] for s in per_gpu),
                                 shares_rej=sum(s['rejected'] for s in per_gpu),
                                 temp_per_gpu=temps, power_w=power)
                last_stat_ts = now
    finally:
        STOP_EVENT.set()
        for w in workers:
            w.join(timeout=5.0)

# =============== CLI/Main ===============
def main():
    signal.signal(signal.SIGTERM, sigterm_handler)

    p = argparse.ArgumentParser(description="ETC server-only OpenCL miner")
    p.add_argument("--config", default="config.json", help="Path to config.json")
    # Optional CLI overrides (take precedence):
    p.add_argument("--server", help="Coordinator server URL, e.g. http://127.0.0.1:9000")
    p.add_argument("--dag", help="Path to DAG file (with 8-byte header)")
    p.add_argument("--kernel", help="OpenCL kernel path, e.g. ./kernel.cl")
    # ocl-build-opts değerleri artık kullanılmıyor, hard coded gömülü okumayı kolaylastirmak için bırakıldı.
    p.add_argument("--ocl-build-opts", help="e.g. -DINDEX_MOD=32 -DPARENTS=64 -DEPOCH_LENGTH=60000 -DETCHASH=1")
    p.add_argument("--global-work", type=int)
    p.add_argument("--workgroup-size", type=int)

    """ bu değerlerin otomatik hesaplanmasını istersek, değerleri 0 olarak gönderiyoruz, değer vermek istersek aşağıdaki gibi
    "global_work": 27840256,
    "workgroup_size": 256,
    """
    p.add_argument("--want-ms", type=int)
    p.add_argument("--log-dir")
    p.add_argument("--stats-dir")
    p.add_argument("--worker")
    p.add_argument("--wallet")
    p.add_argument("--coinbase", help="API key source;  0x, the prefix will be stripped")    
    p.add_argument("--debug", action="store_true")
    args = p.parse_args()

    # 1) Load base config
    base_cfg = load_cfg(args.config)

    # 2) ENV overrides (HiveOS etc.)
    env_cfg = env_overrides()

    # 3) CLI overrides mapped to config keys
    cli_cfg = {"server": {}, "mining": {}, "identity": {}, "logging": {}}
    if args.server:        cli_cfg["server"]["url"] = args.server
    if args.dag:           cli_cfg["mining"]["dag_dir"] = args.dag
    if args.kernel:        cli_cfg["mining"]["kernel_path"] = args.kernel
    if args.ocl_build_opts:cli_cfg["mining"]["ocl_build_opts"] = args.ocl_build_opts
    if args.global_work:   cli_cfg["mining"]["global_work"] = args.global_work
    if args.workgroup_size:cli_cfg["mining"]["workgroup_size"] = args.workgroup_size
    if args.want_ms:       cli_cfg["mining"]["want_ms"] = args.want_ms
    if args.log_dir:       cli_cfg["logging"]["log_dir"] = args.log_dir
    if args.stats_dir:     cli_cfg["logging"]["stats_dir"] = args.stats_dir
    if args.worker:        cli_cfg["identity"]["worker"] = args.worker
    if args.wallet:        cli_cfg["identity"]["wallet"] = args.wallet
    if args.coinbase:      cli_cfg["identity"]["coinbase"] = args.coinbase
    if args.debug:         cli_cfg["logging"]["debug"] = True

    # 4) Merge: CLI > ENV > config
    merged = deep_merge(base_cfg, env_cfg)
    merged = deep_merge(merged, cli_cfg)

    global API_HEADERS
    _api = (merged.get("identity", {}).get("coinbase") or "").strip()
    if _api.lower().startswith("0x"):
        _api = _api[2:]

    if _api:
        API_HEADERS = {"Connection": "close", "X-API-KEY": str(_api)}
        log(f"[AUTH] X-API-KEY set ({len(_api)} hex chars)")
    else:
        API_HEADERS = {"Connection": "close"}
        log("[AUTH] No coinbase -> X-API-KEY header NOT set")

    # 5) Validate minimal fields
    minimal_validate(merged)

    # 6) Resolve paths & ensure dirs
    mining  = merged.get("mining", {})
    logging = merged.get("logging", {})
    server_url = merged["server"]["url"]

    kernel_path = resolve_path(mining.get("kernel_path", "./kernel.cl"))
    dag_path    = resolve_path(mining.get("dag_dir"))   
    log_dir     = resolve_path(logging.get("log_dir", "./logs"))
    stats_dir   = resolve_path(logging.get("stats_dir", "./stats"))
    debug       = bool(logging.get("debug", False))

    ensure_dirs(log_dir, stats_dir)

    if cl is None:
        print("[ERR] pyopencl missing. Install pyopencl.", flush=True); sys.exit(2)

    # 7) Map DAG
    if not dag_path or not Path(dag_path).exists():
        print(f"[ERR] DAG path not found: {dag_path}", flush=True); sys.exit(2)

    if Path(dag_path).is_file():
        print(f"[ERR] 'dag_dir' için klasör bekleniyordu, dosya geldi: {dag_path}", flush=True)
        sys.exit(2)

    if not Path(kernel_path).exists():
        print(f"[ERR] kernel file not found: {kernel_path}", flush=True); sys.exit(2)

    # 8) Sizes/defaults
    global_work    = int(mining.get("global_work", 256*1024) or 256*1024)
    workgroup_size = int(mining.get("workgroup_size", 256) or 256)
    want_ms        = int(mining.get("want_ms", 800) or 800)

    # 9) Run server-mode loop
    run_opencl_with_server(
        dag_dir_path    = dag_path,          # <== klasör
        server_url      = server_url,
        cl_file         = Path(kernel_path),
        build_opts      = mining.get("ocl_build_opts", ""),
        stats_dir       = stats_dir,
        global_work     = global_work,
        workgroup_size  = workgroup_size,
        want_ms         = want_ms,
        debug           = debug,
    )


if __name__ == "__main__":
    main()
