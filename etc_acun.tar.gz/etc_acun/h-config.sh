#!/usr/bin/env bash
set -euo pipefail

echo "[OK] Mevcut config.json dosyası kullanılacak Flight Sheet in değil."

