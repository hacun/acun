cat << 'EOF' | tee /hive/miners/custom/etc_acun/h-config.sh >/dev/null
#!/usr/bin/env bash
echo "${CUSTOM_MINER_CONFIG:-}" > /hive/miners/custom/etc_acun/config.json
EOF

chmod +x /hive/miners/custom/etc_acun/h-config.sh
