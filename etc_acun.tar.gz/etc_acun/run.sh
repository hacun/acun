#!/usr/bin/env bash
set -euo pipefail

export PYTHONUNBUFFERED=1
export MINER_NAME="etc_acun"

# Bu dosyanın bulunduğu dizin -> MINER_DIR
export MINER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-${0}}")" && pwd || echo "/hive/miners/custom/${MINER_NAME}")"

# Klasör adını gerçek dizine uyduralım: sende "dag" var (eski script "dags" diyordu)
export DAG_DIR="${MINER_DIR}/dags"
export VENV_DIR="${MINER_DIR}/venv"
export LOG_DIR="/var/log/miner/${MINER_NAME}"
export STATS_DIR="${MINER_DIR}/stats"

# Flight Sheet tarafında özel isim gelirse onu kullan; yoksa config.json
export CUSTOM_CONFIG_FILENAME="${CUSTOM_CONFIG_FILENAME:-config.json}"
export CFG_PATH="${MINER_DIR}/${CUSTOM_CONFIG_FILENAME}"

# ------------ OpenCL / ICD ayarların (aynen korunuyor) ------------
# Sadece NVIDIA ICD kullan
export OCL_ICD_VENDORS=/etc/OpenCL/vendors/nvidia.icd
# HiveOS’un /hive/lib yolunu baypas edip sistem ICD loader’ını öne al
export LD_LIBRARY_PATH="/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH:-}"
# (Geçici debug’u kapat)
unset OCL_ICD_DEBUG
# ------------------------------------------------------------------

mkdir -p "${LOG_DIR}" "${DAG_DIR}" "${STATS_DIR}"

echo "[DBG] MINER_DIR=${MINER_DIR}"
echo "[DBG] CFG_PATH=${CFG_PATH}"
echo "[DBG] DAG_DIR=${DAG_DIR}"
echo "[DBG] VENV_DIR=${VENV_DIR}"

echo "[INFO] Python3 kontrol ediliyor…"
if ! command -v python3 >/dev/null 2>&1; then
  echo "[WARN] python3 yok, kuruluyor…"
  apt update -y >/dev/null 2>&1 || true
  apt install -y python3 python3-venv python3-pip >/dev/null 2>&1 || {
    echo "[ERR] python3 kurulamadı!"; exit 1; }
else
  echo "[INFO] python3 bulundu: $(python3 --version)"
fi

# /usr/bin/python symlink (bazı ortamlar istiyor)
[ -x /usr/bin/python ] || ln -sf "$(command -v python3)" /usr/bin/python

# --- VENV ve PIP Bootstrap (sağlam) ---
PYBIN="$(command -v python3)"

# venv yoksa oluştur
if [ ! -x "${VENV_DIR}/bin/python" ]; then
  echo "[INFO] venv oluşturuluyor…"
  "$PYBIN" -m venv "${VENV_DIR}" 2>/dev/null || "$PYBIN" -m venv "${VENV_DIR}" --without-pip || true
fi

# 1) ensurepip ile pip kur/yenile
if ! "${VENV_DIR}/bin/python" -m pip -V >/dev/null 2>&1; then
  echo "[INFO] venv içinde pip bootstrap (ensurepip)…"
  if ! "${VENV_DIR}/bin/python" -m ensurepip --upgrade --default-pip >/dev/null 2>&1; then
    echo "[WARN] ensurepip yok/çalışmadı, OS paketleri kuruluyor…"
    apt update -y >/dev/null 2>&1 || true
    apt install -y python3-venv python3-pip python3-distutils >/dev/null 2>&1 || true
    # tekrar dene
    "${VENV_DIR}/bin/python" -m ensurepip --upgrade --default-pip >/dev/null 2>&1 || true
  fi
fi

# 2) pip hâlâ yoksa: venv'i system-site-packages ile yeniden kur (acı ama pratik)
if ! "${VENV_DIR}/bin/python" -m pip -V >/dev/null 2>&1; then
  echo "[WARN] venv pip yok; venv yeniden kuruluyor (--system-site-packages)…"
  rm -rf "${VENV_DIR}"
  "$PYBIN" -m venv "${VENV_DIR}" --system-site-packages
fi

# 3) pip’i güncelle
if "${VENV_DIR}/bin/python" -m pip -V >/dev/null 2>&1; then
  "${VENV_DIR}/bin/python" -m pip install -U pip setuptools wheel >/dev/null 2>&1 || true
else
  echo "[ERR] venv içinde pip oluşturulamadı."
fi

PYBIN="${VENV_DIR}/bin/python"
echo "[INFO] venv aktif: $("$PYBIN" --version)"


# Bağımlılıklar (dosya hem var hem de boş değilse)
if [ -s "${MINER_DIR}/requirements.txt" ]; then
  echo "[INFO] pip bağımlılıkları yükleniyor…"
  "$PYBIN" -m pip install --upgrade pip setuptools wheel >/dev/null 2>&1 || true
  "$PYBIN" -m pip install --no-cache-dir -r "${MINER_DIR}/requirements.txt" >>"${LOG_DIR}/pip.log" 2>&1 || {
    echo "[WARN] pip install hatası (log: ${LOG_DIR}/pip.log)"; }
else
  echo "[INFO] requirements.txt yok/boş, atlanıyor."
fi

# Config içeriği Flight Sheet’ten geliyorsa yaz; yoksa dosyanın kökte olduğundan emin ol
if [ -n "${CUSTOM_MINER_CONFIG:-}" ]; then
  echo "${CUSTOM_MINER_CONFIG}" > "${CFG_PATH}"
  echo "[INFO] CUSTOM_MINER_CONFIG yazıldı → ${CFG_PATH}"
else
  if [ ! -f "${CFG_PATH}" ]; then
    echo "[ERR] Config dosyası bulunamadı: ${CFG_PATH}"
    exit 2
  fi
  echo "[INFO] config.json yerel dosyadan kullanılacak → ${CFG_PATH}"
fi

echo "[INFO] ${MINER_NAME} başlatılıyor…"

# Çalıştır ve log'a yaz
exec "$PYBIN" -u "${MINER_DIR}/etc_acun.py" --config "${CFG_PATH}" >> "${LOG_DIR}/${MINER_NAME}.log" 2>&1
