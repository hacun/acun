set -eo pipefail
export PYTHONUNBUFFERED=1
export MINER_NAME="etc_acun"
export MINER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-${0}}")" && pwd || echo "/hive/miners/${MINER_NAME}")"
export VENV_DIR="${MINER_DIR}/venv"
export LOG_DIR="/var/log/miner/${MINER_NAME}"
export DAG_DIR="${MINER_DIR}/data"
export STATS_DIR="${MINER_DIR}/stats"
export CFG_PATH="${MINER_DIR}/config.json"
# OpenCL: sadece NVIDIA ICD kullan
export OCL_ICD_VENDORS=/etc/OpenCL/vendors/nvidia.icd
# HiveOS’un /hive/lib yolunu baypas edip sistem ICD loader’ını öne al
export LD_LIBRARY_PATH=/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:${LD_LIBRARY_PATH}
# (Geçici debug’u kapat)
unset OCL_ICD_DEBUG
mkdir -p "${LOG_DIR}" "${DAG_DIR}" "${STATS_DIR}"
echo "[INFO] Python3 kontrol ediliyor…"
if ! command -v python3 >/dev/null 2>&1; then
  echo "[WARN] python3 yok, kuruluyor…"
  apt update -y >/dev/null 2>&1 || true
  apt install -y python3 python3-venv python3-pip >/dev/null 2>&1 || {
    echo "[ERR] python3 kurulamadı!"; exit 1; }
else
  echo "[INFO] python3 bulundu: $(python3 --version)"
fi
[ -x /usr/bin/python ] || ln -sf "$(command -v python3)" /usr/bin/python
PYBIN="$(command -v python3)"
if [ ! -x "${VENV_DIR}/bin/python" ]; then
  echo "[INFO] venv oluşturuluyor…"
  "$PYBIN" -m venv "${VENV_DIR}" --upgrade-deps 2>/dev/null || "$PYBIN" -m venv "${VENV_DIR}" || true
fi
if [ ! -x "${VENV_DIR}/bin/pip" ]; then
  echo "[INFO] venv içinde pip bootstrap ediliyor…"
  "${VENV_DIR}/bin/python" -m ensurepip --upgrade >/dev/null 2>&1 || true
  if [ ! -x "${VENV_DIR}/bin/pip" ]; then
    # sistem pip kurulu (apt) — venv içine yükselt
    apt install -y python3-pip >/dev/null 2>&1 || true
    "${VENV_DIR}/bin/python" -m ensurepip --upgrade >/dev/null 2>&1 || true
  fi
fi
if [ -x "${VENV_DIR}/bin/python" ]; then
  PYBIN="${VENV_DIR}/bin/python"
  echo "[INFO] venv aktif: $("$PYBIN" --version)"
else
  echo "[WARN] venv kullanılamadı, sistem python3 ile devam."
fi
if [ -f "${MINER_DIR}/requirements.txt" ]; then
  echo "[INFO] pip bağımlılıkları yükleniyor…"
  "$PYBIN" -m pip install --upgrade pip setuptools wheel >/dev/null 2>&1 || true
  "$PYBIN" -m pip install --no-cache-dir -r "${MINER_DIR}/requirements.txt" >>"${LOG_DIR}/pip.log" 2>&1 || {
    echo "[WARN] pip install hatası (log: ${LOG_DIR}/pip.log)"; }
else
  echo "[INFO] requirements.txt yok, atlanıyor."
fi
if [ -n "${CUSTOM_MINER_CONFIG:-}" ]; then
  echo "${CUSTOM_MINER_CONFIG}" > "${CFG_PATH}"
  echo "[INFO] CUSTOM_MINER_CONFIG yazıldı → ${CFG_PATH}"
else
  echo "[INFO] config.json yerel dosyadan kullanılacak → ${CFG_PATH}"
fi
echo "[INFO] ${MINER_NAME} başlatılıyor…"
exec "$PYBIN" -u "${MINER_DIR}/main.py" --config "${CFG_PATH}" >> "${LOG_DIR}/${MINER_NAME}.log" 2>&1
